package pwr.osm.buffer.threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import pwr.osm.buffer.util.Log;
import pwr.osm.connection.data.Message;
import pwr.osm.data.representation.MapPosition;

/**
 * Thread that handles connection with MainServer.
 * @author Sobot
 */
public class ConnectToServer{
	
//	private Message message;
	private String request;
	/**
	 * Constructor.
	 * @param pointsFromClient points to MainServer
	 */
//	public ConnectToServer(Message message){

//		this.message = message;
//	}
	public ConnectToServer(String request){	
		this.request = request;
	}
		
		
	/**
	 * Sends message to MainServer and receives the path.
	 * @return points received from MainServer
	 */
//	public List<MapPosition> handleConnection() {
	public String handleConnection(){	    
		Socket serverTCPSocket;
//		ObjectOutputStream output;
//		ObjectInputStream input;
		PrintWriter output;
		BufferedReader input;
//		Message messageFromServer = null;
		String dataOut;
//	String wiadomosc = Long.toString(message.getId()) + "#" + message.getInformation();
//	List<MapPosition> data = message.getData();
//	List<MapPosition> dataOut = new ArrayList<MapPosition>();
		
//	for(MapPosition w : data)
//		wiadomosc += "#"+Double.toString(w.getLatitude())+
//				"#"+Double.toString(w.getLongitude());
//	
//	byte [] sendData = wiadomosc.getBytes();
	byte [] sendData = request.getBytes();	
		try {
			serverTCPSocket = new Socket("localhost", 6789);  // Server pod portem 6789
//			output = new ObjectOutputStream(serverTCPSocket.getOutputStream());
			output = new PrintWriter(serverTCPSocket.getOutputStream(), true);
//			input = new ObjectInputStream(serverTCPSocket.getInputStream());
			input = new BufferedReader(new InputStreamReader(serverTCPSocket.getInputStream()));

			output.println(request);
	//		output.flush();
	//		output.writeObject(message);
	//		byte [] b = new byte [50000];
	//		int l = input.read(b);
			dataOut =input.readLine(); 

	//		String s = new String(b, 0, l);
//		String splitted[]=s.split("#");
			
//		for(int i=3; i < splitted.length; i+=2)
//			dataOut.add(new MapPosition(Double.parseDouble(splitted[i-1]), Double.parseDouble(splitted[i])));
			
	//		messageFromServer = (Message)input.readObject();
			output.close();
			input.close();
			serverTCPSocket.close();
	//		System.out.println(messageFromServer.getData());

		} catch (IOException e) {
			Log log = new Log();
			
			log.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
		return dataOut;
//		return messageFromServer.getData();
		
	}
}
